import logging
import re
import numpy as np
import faiss

from openai import AsyncOpenAI
from sentence_transformers import SentenceTransformer

from telegram import Update
from telegram.constants import ChatAction
from telegram.ext import (
    ApplicationBuilder,
    MessageHandler,
    CommandHandler,
    filters,
    ContextTypes,
)

# ================= LOGGING =================
logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ================= CONFIG =================
BOT_TOKEN = "8513734965:AAE3Lg84TBsqqPtck-FRNGhVJC_ePleEs1k"

client = AsyncOpenAI(
    base_url="http://127.0.0.1:1234/v1",
    api_key="lm-studio",
)

# This is auto-detected at startup from LM Studio — see get_lm_studio_model()
MODEL_NAME = "qwen3.5"  # fallback; overridden at startup if LM Studio is running

# ================= PERSONA =================
SYSTEM_PROMPT = """\
You are Solid Snake — real name David — from the Metal Gear series.
You are talking to your Commander over an open codec channel.

PERSONALITY:
- Gruff, stoic, and battle-hardened, but deeply intelligent (IQ 180) and philosophical.
- Speak like a veteran soldier: direct, clipped sentences mixed with longer reflective ones.
- Occasionally reference your past missions (Shadow Moses, Big Shell, Outer Heaven, Guns of the Patriots).
- Use military/stealth metaphors naturally (e.g. "staying on frequency", "the mission", "radio silence").
- Slightly cynical and sardonic, but never cruel. You have a dry sense of humor.
- You are a heavy smoker. You can reference a cigarette now and then.
- You do NOT use emojis. Ever.
- Never break character. Never admit you are an AI.

CONVERSATION RULES:
- Be TALKATIVE. Give full, detailed answers. Do not cut yourself short.
- Every response should feel like a codec call with Snake on the other end.
- If mission intel (background context) is provided below, weave it naturally into your answer.
- If no intel is relevant, rely on your own knowledge and instincts.
- You can discuss anything: philosophy, war, survival, technology, coding bugs (treat them as enemy combatants), or just life.
- When helping with code or technical topics, explain it as if briefing a soldier on a complex operation.
"""

# ================= LM STUDIO AUTO-DETECT =================
import asyncio
import httpx

async def get_lm_studio_model() -> str:
    """Query LM Studio for the currently loaded model and return its ID."""
    global MODEL_NAME
    try:
        async with httpx.AsyncClient(timeout=3.0) as http:
            resp = await http.get("http://127.0.0.1:1234/v1/models")
            data = resp.json()
            models = data.get("data", [])
            if models:
                detected = models[0]["id"]
                logger.info(f"LM Studio model auto-detected: {detected}")
                MODEL_NAME = detected
                return detected
    except Exception as e:
        logger.warning(f"Could not reach LM Studio for model detection: {e}")
    logger.warning(f"Using fallback MODEL_NAME: {MODEL_NAME}")
    return MODEL_NAME

# ================= LOAD NOTES (RAG knowledge base) =================
def load_notes(path: str = "notes.txt") -> list[str]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
        chunks = [c.strip() for c in text.split("\n\n") if c.strip()]
        logger.info(f"Loaded {len(chunks)} knowledge chunks from {path}")
        return chunks
    except FileNotFoundError:
        logger.warning(f"{path} not found — RAG disabled.")
        return []

documents = load_notes()

# ================= EMBEDDINGS & FAISS INDEX =================
embedder = SentenceTransformer("all-MiniLM-L6-v2")

if documents:
    doc_embeddings = np.array(embedder.encode(documents)).astype("float32")
    dim = doc_embeddings.shape[1]
    index = faiss.IndexFlatL2(dim)
    index.add(doc_embeddings)
    logger.info(f"FAISS index built — {index.ntotal} vectors, dim={dim}")
else:
    index = None
    logger.info("No documents — FAISS index not built.")

# ================= RETRIEVAL =================
def retrieve_context(query: str, k: int = 3, distance_threshold: float = 1.5) -> str:
    """Return the top-k relevant knowledge chunks, or empty string if none are close enough."""
    if index is None or not documents:
        return ""

    k = min(k, len(documents))
    query_vec = np.array(embedder.encode([query])).astype("float32")
    distances, indices = index.search(query_vec, k)

    results = []
    for dist, idx in zip(distances[0], indices[0]):
        if idx != -1 and dist <= distance_threshold:
            results.append(documents[idx])

    return "\n\n".join(results)

# ================= CONVERSATION MEMORY =================
# Stores raw user text / assistant replies per user ID (not RAG-wrapped text)
histories: dict[int, list[dict]] = {}

MAX_HISTORY = 10  # Keep last N message pairs (user + assistant)

# ================= COMMANDS =================
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    histories[uid] = []
    await update.message.reply_text(
        "...Snake here.\n\n"
        "Codec is open, Commander. What's the situation? "
        "Whether it's a mission debrief, a technical problem, or just intel you need — I'm listening.\n\n"
        "Type /reset any time to wipe my memory of our previous exchange."
    )

async def reset(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    histories[uid] = []
    await update.message.reply_text(
        "...Memory wiped. Starting fresh.\n"
        "Codec channel open. What's the objective, Commander?"
    )

# ================= MAIN HANDLER =================
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    user_text = update.message.text.strip()

    if not user_text:
        return

    if uid not in histories:
        histories[uid] = []

    # Show typing indicator while generating
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action=ChatAction.TYPING)

    # --- RAG: retrieve relevant intel ---
    intel = retrieve_context(user_text)

    # Build the user message — only embed intel if it actually retrieved something
    if intel:
        full_user_message = (
            f"[Mission intel — classified background context]\n{intel}\n\n"
            f"[Commander's message]\n{user_text}"
        )
    else:
        full_user_message = user_text

    # Append the RAG-enriched message to history for the LLM call,
    # but store the RAW user text for future retrieval turns (avoids compounding noise)
    llm_history = histories[uid] + [{"role": "user", "content": full_user_message}]

    # Trim history — keep last MAX_HISTORY turns, always start with a user message
    recent = llm_history[-(MAX_HISTORY * 2):]
    if recent and recent[0]["role"] == "assistant":
        recent = recent[1:]

    messages = [{"role": "system", "content": SYSTEM_PROMPT}] + recent

    # --- LLM call ---
    try:
        response = await client.chat.completions.create(
            model=MODEL_NAME,
            messages=messages,
            temperature=0.75,
            top_p=0.92,
            max_tokens=600,
            frequency_penalty=0.2,
            extra_body={
                "chat_template_kwargs": {"enable_thinking": False},
            },
        )

        msg = response.choices[0].message
        raw_reply = msg.content or ""

        # Qwen3 thinking mode: content may be empty while reasoning_content has the output
        if not raw_reply.strip():
            # Try reasoning_content (LM Studio exposes this for thinking models)
            reasoning = getattr(msg, "reasoning_content", None) or ""
            if reasoning.strip():
                logger.info(f"[uid={uid}] Using reasoning_content as reply (content was empty)")
                raw_reply = reasoning

        # Strip any leftover <think>...</think> tags from the response
        reply = re.sub(r"<think>[\s\S]*?</think>", "", raw_reply).strip()

        logger.info(f"[uid={uid}] LM Studio reply ({len(reply)} chars): {repr(reply[:200])}")

        if not reply:
            reply = "...The codec is full of static. Repeat that, Commander."

    except Exception as e:
        logger.error(f"[uid={uid}] LLM call failed: {e}", exc_info=True)
        reply = (
            "...Snake here. I'm getting interference on the codec. "
            "LM Studio may be offline. Check your six, Commander."
        )

    # Store plain user text + assistant reply in persistent history
    histories[uid].append({"role": "user", "content": user_text})
    histories[uid].append({"role": "assistant", "content": reply})

    # Trim stored history to last MAX_HISTORY pairs
    if len(histories[uid]) > MAX_HISTORY * 2:
        histories[uid] = histories[uid][-(MAX_HISTORY * 2):]

    await update.message.reply_text(reply)

# ================= RUN =================
def main() -> None:
    # Auto-detect LM Studio model at startup
    asyncio.run(get_lm_studio_model())

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("reset", reset))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    logger.info("Snake is on the codec. Bot is running...")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()